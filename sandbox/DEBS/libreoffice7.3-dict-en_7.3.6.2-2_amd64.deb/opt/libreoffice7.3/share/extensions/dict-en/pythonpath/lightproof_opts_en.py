lopts = {}
lopts_default = {}
lopts['en'] = [u'grammar', u'cap', u'dup', u'pair', u'spaces', u'mdash', u'quotation', u'times', u'spaces2', u'ndash', u'apostrophe', u'ellipsis', u'spaces3', u'minus', u'metric', u'numsep', u'nonmetric']
lopts_default['en'] = [u'spaces', u'times']
