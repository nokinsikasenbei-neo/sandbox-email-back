OpenThesaurus - Tesauro Español - Versión para LibreOffice/Apache OpenOffice
Marcelo Garrone (mgarrone at users.sf.net)
Snapshot, generado automáticamente: 2012-01-11 21:33
Homepage: http://openthes-es.berlios.de

Requisitos: ==========================================================

LibreOffice/Apache OpenOffice

Nota: ================================================================
    
  * El diccionario de sinónimos y separación silábica es el mismo para Windows como para Linux.

licencia: =========================================================

LGPL 2.1: 
  - https://www.gnu.org/licenses/old-licenses/lgpl-2.1.en.html
  - fichero COPYING
